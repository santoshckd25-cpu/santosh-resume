SANTOSH S KATTIMANI - DIGITAL RESUME WITH GREAT LEARNING-STYLE SAMPLE CERTIFICATES

Included:
- index.html
- profile.jpg
- certificates/ai-prompt-engineering.png
- certificates/web-design.png
- certificates/data-analyst.png

IMPORTANT:
These are custom portfolio/sample certificates inspired by a professional e-learning certificate aesthetic. They are NOT official certificates issued by Great Learning and should not be represented as such.
