SANTOSH S KATTIMANI — DIGITAL RESUME PORTFOLIO

Files:
- index.html : complete responsive resume website
- assets/profile.jpg : uploaded profile photo

Open index.html in any modern browser to preview the website.

For a public link, upload this folder to a static hosting service such as GitHub Pages or Netlify. The index.html file should remain at the top level.
